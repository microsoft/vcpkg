// ╔══════════════════════════════════════════════════════════════════╗
// ║  vgui :: AppConfig  –  implementation                           ║
// ║  (Header-only struct; this TU exists for future extensions.)    ║
// ╚══════════════════════════════════════════════════════════════════╝

#include <vgui/core/config.hpp>
