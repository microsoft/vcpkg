// ╔══════════════════════════════════════════════════════════════════╗
// ║  vgui :: Vulkan backend – vk_renderpass                                  ║
// ╚══════════════════════════════════════════════════════════════════╝
#if defined(VGUI_BACKEND_VULKAN)
#include <vulkan/vulkan.h>
namespace vgui::vk { /* vk_renderpass implementation */ }
#endif
