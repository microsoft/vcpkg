// ╔══════════════════════════════════════════════════════════════════╗
// ║  vgui :: Vulkan backend – vk_texture                                  ║
// ╚══════════════════════════════════════════════════════════════════╝
#if defined(VGUI_BACKEND_VULKAN)
#include <vulkan/vulkan.h>
namespace vgui::vk { /* vk_texture implementation */ }
#endif
