// ╔══════════════════════════════════════════════════════════════════╗
// ║  vgui :: Vulkan backend – vk_image                                  ║
// ╚══════════════════════════════════════════════════════════════════╝
#if defined(VGUI_BACKEND_VULKAN)
#include <vulkan/vulkan.h>
namespace vgui::vk { /* vk_image implementation */ }
#endif
