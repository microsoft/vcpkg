// ╔══════════════════════════════════════════════════════════════════╗
// ║  vgui :: Vulkan backend – vk_shader                                  ║
// ╚══════════════════════════════════════════════════════════════════╝
#if defined(VGUI_BACKEND_VULKAN)
#include <vulkan/vulkan.h>
namespace vgui::vk { /* vk_shader implementation */ }
#endif
