// ╔══════════════════════════════════════════════════════════════════╗
// ║  vgui :: Vulkan backend – vk_barrier                                  ║
// ╚══════════════════════════════════════════════════════════════════╝
#if defined(VGUI_BACKEND_VULKAN)
#include <vulkan/vulkan.h>
namespace vgui::vk { /* vk_barrier implementation */ }
#endif
