// ╔══════════════════════════════════════════════════════════════════╗
// ║  vgui :: Metal backend – mtl_device                                   ║
// ╚══════════════════════════════════════════════════════════════════╝
#if defined(VGUI_BACKEND_METAL)
#import <Metal/Metal.h>
#import <MetalKit/MetalKit.h>
namespace vgui::mtl { /* mtl_device implementation */ }
#endif
