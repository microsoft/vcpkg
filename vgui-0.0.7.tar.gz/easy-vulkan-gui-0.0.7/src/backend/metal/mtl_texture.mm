// ╔══════════════════════════════════════════════════════════════════╗
// ║  vgui :: Metal backend – mtl_texture                                   ║
// ╚══════════════════════════════════════════════════════════════════╝
#if defined(VGUI_BACKEND_METAL)
#import <Metal/Metal.h>
#import <MetalKit/MetalKit.h>
namespace vgui::mtl { /* mtl_texture implementation */ }
#endif
