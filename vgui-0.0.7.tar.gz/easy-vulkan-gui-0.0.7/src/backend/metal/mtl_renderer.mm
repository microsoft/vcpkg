// ╔══════════════════════════════════════════════════════════════════╗
// ║  vgui :: Metal backend – mtl_renderer                                   ║
// ╚══════════════════════════════════════════════════════════════════╝
#if defined(VGUI_BACKEND_METAL)
#import <Metal/Metal.h>
#import <MetalKit/MetalKit.h>
namespace vgui::mtl { /* mtl_renderer implementation */ }
#endif
