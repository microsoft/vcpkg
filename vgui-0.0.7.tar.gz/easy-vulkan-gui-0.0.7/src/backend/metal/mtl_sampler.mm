// ╔══════════════════════════════════════════════════════════════════╗
// ║  vgui :: Metal backend – mtl_sampler                                   ║
// ╚══════════════════════════════════════════════════════════════════╝
#if defined(VGUI_BACKEND_METAL)
#import <Metal/Metal.h>
#import <MetalKit/MetalKit.h>
namespace vgui::mtl { /* mtl_sampler implementation */ }
#endif
