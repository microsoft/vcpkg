// ╔══════════════════════════════════════════════════════════════════╗
// ║  vgui :: Metal backend – mtl_swapchain                                   ║
// ╚══════════════════════════════════════════════════════════════════╝
#if defined(VGUI_BACKEND_METAL)
#import <Metal/Metal.h>
#import <MetalKit/MetalKit.h>
namespace vgui::mtl { /* mtl_swapchain implementation */ }
#endif
