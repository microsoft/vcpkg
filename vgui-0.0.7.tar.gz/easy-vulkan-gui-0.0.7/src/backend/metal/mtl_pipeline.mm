// ╔══════════════════════════════════════════════════════════════════╗
// ║  vgui :: Metal backend – mtl_pipeline                                   ║
// ╚══════════════════════════════════════════════════════════════════╝
#if defined(VGUI_BACKEND_METAL)
#import <Metal/Metal.h>
#import <MetalKit/MetalKit.h>
namespace vgui::mtl { /* mtl_pipeline implementation */ }
#endif
