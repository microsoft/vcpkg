// ╔══════════════════════════════════════════════════════════════════╗
// ║  vgui :: Metal backend – mtl_buffer                                   ║
// ╚══════════════════════════════════════════════════════════════════╝
#if defined(VGUI_BACKEND_METAL)
#import <Metal/Metal.h>
#import <MetalKit/MetalKit.h>
namespace vgui::mtl { /* mtl_buffer implementation */ }
#endif
