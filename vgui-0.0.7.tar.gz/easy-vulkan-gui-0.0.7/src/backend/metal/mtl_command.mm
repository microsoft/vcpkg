// ╔══════════════════════════════════════════════════════════════════╗
// ║  vgui :: Metal backend – mtl_command                                   ║
// ╚══════════════════════════════════════════════════════════════════╝
#if defined(VGUI_BACKEND_METAL)
#import <Metal/Metal.h>
#import <MetalKit/MetalKit.h>
namespace vgui::mtl { /* mtl_command implementation */ }
#endif
