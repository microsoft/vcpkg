// vgui :: backend common – gpu stub
#include <vgui/core/logger.hpp>
namespace vgui { /* gpu implementation */ }
