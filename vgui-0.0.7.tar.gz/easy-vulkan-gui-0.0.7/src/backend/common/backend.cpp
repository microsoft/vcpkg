// vgui :: backend common – backend stub
#include <vgui/core/logger.hpp>
namespace vgui { /* backend implementation */ }
