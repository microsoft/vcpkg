// vgui :: backend common – allocator stub
#include <vgui/core/logger.hpp>
namespace vgui { /* allocator implementation */ }
