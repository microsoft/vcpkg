// vgui :: backend common – memory stub
#include <vgui/core/logger.hpp>
namespace vgui { /* memory implementation */ }
