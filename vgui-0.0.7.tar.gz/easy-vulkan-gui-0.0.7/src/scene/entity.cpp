#include <vgui/scene/entity.hpp>
// Entity is mostly header-only template-based; this TU keeps linker happy.
namespace vgui {}
