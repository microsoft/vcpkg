#include <vgui/scene/light.hpp>
// Light is a plain struct; this TU exists for future extensions.
namespace vgui {}
