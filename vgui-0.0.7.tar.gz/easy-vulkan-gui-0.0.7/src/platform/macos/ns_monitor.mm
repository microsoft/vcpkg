// vgui :: macOS monitor enumeration (thin wrapper over CGDisplay)
#if defined(__APPLE__)
#import <CoreGraphics/CoreGraphics.h>
namespace vgui { /* CGGetActiveDisplayList wrappers */ }
#endif
