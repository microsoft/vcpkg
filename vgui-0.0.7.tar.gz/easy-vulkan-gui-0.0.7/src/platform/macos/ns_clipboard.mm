// vgui :: macOS clipboard – implementation in window/clipboard.cpp via ObjC bridge
#if defined(__APPLE__)
namespace vgui { /* NSPasteboard calls are in src/window/clipboard.cpp */ }
#endif
