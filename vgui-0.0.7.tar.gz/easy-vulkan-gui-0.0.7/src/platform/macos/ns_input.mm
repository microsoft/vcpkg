// vgui :: macOS input – NSEvent handling delegated from NSWindow
// Key/mouse events come through the NSWindow event loop in ns_window.mm.
#if defined(__APPLE__)
#import <Cocoa/Cocoa.h>
namespace vgui { /* NSEvent key/mouse helpers */ }
#endif
