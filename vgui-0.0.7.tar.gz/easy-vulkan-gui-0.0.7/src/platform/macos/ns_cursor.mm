// vgui :: macOS cursor shapes
#if defined(__APPLE__)
#import <Cocoa/Cocoa.h>
namespace vgui { /* [NSCursor arrowCursor] etc. */ }
#endif
