// vgui :: Wayland input (future)
#if defined(__linux__)
namespace vgui { /* wl_seat, wl_keyboard, wl_pointer */ }
#endif
