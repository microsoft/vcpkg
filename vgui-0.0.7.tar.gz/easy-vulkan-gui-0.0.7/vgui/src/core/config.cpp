#include "vgui/core/config.hpp"

namespace vgui {

// Config implementation is header-only

} // namespace vgui
