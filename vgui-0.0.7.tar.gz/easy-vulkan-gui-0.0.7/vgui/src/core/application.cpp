#include "vgui/core/application.hpp"

namespace vgui {

// Application implementation is header-only

} // namespace vgui
