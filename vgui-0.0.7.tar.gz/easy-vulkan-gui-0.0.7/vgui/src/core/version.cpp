#include "vgui/core/version.hpp"

// Version implementation is header-only
namespace vgui {
    // Template instantiations if needed
}
