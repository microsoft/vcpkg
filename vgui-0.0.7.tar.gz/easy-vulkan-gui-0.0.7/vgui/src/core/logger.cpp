#include "vgui/core/logger.hpp"

namespace vgui {

// Logger implementation is header-only

} // namespace vgui
