#include "vgui/backend/common/backend.hpp"

namespace vgui {
namespace backend {

// Backend implementation

} // namespace backend
} // namespace vgui
