#!/bin/sh

curl https://raw.githubusercontent.com/okdshin/PicoSHA2/master/picosha2.h > tool/include/broker/external/picosha2.h
