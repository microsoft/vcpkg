// Copyright Takatoshi Kondo 2022
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#include "../common/test_main.hpp"
#include "../common/global_fixture.hpp"

#include <async_mqtt/protocol/packet/topic_subopts.hpp>

BOOST_AUTO_TEST_SUITE(ut_topic_subopts)


BOOST_AUTO_TEST_CASE( tc1 ) {

}

BOOST_AUTO_TEST_SUITE_END()
